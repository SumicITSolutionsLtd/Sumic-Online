
import React from 'react';
import CartItem from './components/CartItem';
import CartSummary from './components/CartSummary';
import EmptyCart from './components/EmptyCart';
import SavedForLater from './components/SavedForLater';

const CartPage = () => {
  const cartItems = [
    {
      id: 1,
      name: 'Product Name 1',
      image: '/src/media/products/product_1.jpg',
      price: 25.00,
      quantity: 1,
      attributes: {
        color: 'Red',
        size: 'M',
      },
    },
    {
        id: 2,
        name: 'Product Name 2',
        image: '/src/media/products/product_2.jpg',
        price: 35.00,
        quantity: 2,
        attributes: {
          color: 'Blue',
          size: 'L',
        },
      },
  ];

  const savedForLaterItems = [
    {
        id: 3,
        name: 'Product Name 3',
        image: '/src/media/products/product_3.jpg',
        price: 45.00,
        attributes: {
          color: 'Green',
          size: 'S',
        },
      },
  ];

  if (cartItems.length === 0) {
    return <EmptyCart />;
  }

  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Shopping Cart</h1>
      <div className="lg:grid lg:grid-cols-3 lg:gap-8">
        <div className="lg:col-span-2">
          <div className="divide-y divide-gray-200">
            {cartItems.map((item) => (
              <CartItem key={item.id} item={item} />
            ))}
          </div>
        </div>
        <div className="mt-8 lg:mt-0">
          <CartSummary cartItems={cartItems} />
        </div>
      </div>
      <SavedForLater items={savedForLaterItems} />
    </div>
  );
};

export default CartPage;
