
import React from 'react';

const SavedForLater = ({ items }) => {
  if (items.length === 0) {
    return null;
  }

  return (
    <div className="mt-16">
      <h2 className="text-2xl font-bold text-gray-900">Saved for later</h2>
      <div className="mt-6 grid grid-cols-1 gap-y-10 gap-x-6 sm:grid-cols-2 lg:grid-cols-4 xl:gap-x-8">
        {items.map((item) => (
          <div key={item.id} className="group relative">
            <div className="w-full min-h-80 bg-gray-200 aspect-w-1 aspect-h-1 rounded-md overflow-hidden group-hover:opacity-75 lg:h-80 lg:aspect-none">
              <img
                src={item.image}
                alt={item.name}
                className="w-full h-full object-center object-cover lg:w-full lg:h-full"
              />
            </div>
            <div className="mt-4 flex justify-between">
              <div>
                <h3 className="text-sm text-gray-700">
                  <a href="#">
                    <span aria-hidden="true" className="absolute inset-0" />
                    {item.name}
                  </a>
                </h3>
                <p className="mt-1 text-sm text-gray-500">{item.attributes.color}</p>
              </div>
              <p className="text-sm font-medium text-gray-900">${item.price.toFixed(2)}</p>
            </div>
            <div className="mt-4">
                <button className='w-full bg-blue-500 text-white px-4 py-2 rounded-md'>Move to cart</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default SavedForLater;
