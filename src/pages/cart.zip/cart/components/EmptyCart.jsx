
import React from 'react';

const EmptyCart = () => {
  return (
    <div className="text-center py-20">
      <h2 className="text-2xl font-bold text-gray-900">Your cart is empty</h2>
      <p className="mt-2 text-sm text-gray-500">
        Looks like you haven't added anything to your cart yet.
      </p>
      <div className="mt-6">
        <a
          href="/"
          className="text-base font-medium text-indigo-600 hover:text-indigo-500"
        >
          Continue Shopping<span aria-hidden="true"> &rarr;</span>
        </a>
      </div>
    </div>
  );
};

export default EmptyCart;
